/**
 * Created by Vitaly on 16.09.2016.
 */

jQuery( function ( $ ) {

    'use strict';

    var $body = $('body');

    var AWSImport = {

        obj : {
            form     : '#js-aws-bulk',
            panel    : '#aws-form-content',
            parent   : '#parentNodes',
            keywords : '#Keywords',
            apply    : '#aws_selective',
            layout   : '#listProducts',
            results  : '#panel-search-results',
            tmpl     : '#tmpl-listProducts',
            supplier : '.js-supplier-info',
            sort     : $( '#sort' ),
            rows     : '.product-item'
        },

        getLastChildNodeInfo : function () {

            var childSelectsList = [];
            var result = {
                nodeLevel          : 0,
                lastChildNodeValue : 0
            };

            $("#aws-form-content .form-group").each(function() {

                var $this = $( this );
                if( $this.find("select.child-node-select").length ) {
                    result.nodeLevel++;
                    childSelectsList.push( $this.find("select.child-node-select") );
                }

            });

            if( childSelectsList.length ) {
                var lastChildSelect = childSelectsList.pop()[0];
                result.lastChildNodeValue = $(lastChildSelect).val();
            }

            return result;

        },

        createPagination : function ( obj, total, current ) {

            var perPage = 10,
                $t = this;

            current = parseInt( current );

            if ( total > 100 ) total = 100;

            obj.pagination( {
                items       : total,
                itemsOnPage : perPage,
                currentPage : current,
                cssStyle    : "light-theme",
                prevText    : obj.data( 'prev' ),
                nextText    : obj.data( 'next' ),

                onPageClick : function ( pageNumber ) {

                    $t.findByNode( pageNumber );
                }
            } );
        },

        checker : function () {

            var a = $( "#checkAll" ),
                l = $( '#listProducts' );

            a.change( function () {
                l.find( 'input:checkbox' ).prop( 'checked', $( this ).prop( "checked" ) );
            } );

            l.on( 'click', 'input:checkbox', function () {
                var u = l.find( "input:checkbox:not(:checked)" );

                if ( u.length && a.prop( "checked" ) ) {
                    a.prop( "checked", false );
                }
                else if ( u.length == 0 && !a.prop( "checked" ) ) {
                    a.prop( "checked", true );
                }
            } );
        },

        changeParentNode : function(){

            var a = this.obj;

            $(a.parent).on('change', function(){

                $.ajaxQueue( {
                    url     : ajaxurl,
                    data    : {
                        action     : 'ali_aws_change_node',
                        node       : $(this).val(),
                        node_level : 1
                    },
                    type    : "POST",
                    beforeSend : function(){
                        ali.loader(a.panel, 'show');
                    },
                    success : function ( response ) {

                        $(a.panel).html(response);

                        ali.loader(a.panel, 'hide');

                        $('select.selecter').selectpicker('refresh');
                    }
                } );
            });
        },

        changeChildNode : function(){

            var a = this.obj;

            $(".panel-body").on('change', '.child-node-select', function() {

                console.log( "change child select" );

                var child_node_select_val = $(this).val();
                var lastChildNodeInfo = AWSImport.getLastChildNodeInfo();
                var common_node_level = lastChildNodeInfo.nodeLevel;
                var current_node_level = + $(this).attr('id').replace( "ChildNode-", "" );

                var node_level = common_node_level;

                if( current_node_level < node_level ) {
                    node_level = current_node_level;
                    removeOtherChildSelects ( current_node_level, common_node_level );
                }

                function removeOtherChildSelects ( current_node_level, common_node_level ) {
                    if( current_node_level < common_node_level ) {
                        $("#ChildNode-" + common_node_level ).closest("div.form-group").remove();
                        common_node_level --;
                        removeOtherChildSelects ( current_node_level, common_node_level );
                    }
                }

                if ( $(this).val() == '0' ) {
                    return false;
                }

                $.ajaxQueue( {
                    url     : ajaxurl,
                    data    : {
                        action     : 'ali_aws_change_child_node',
                        node       : child_node_select_val,
                        node_level : node_level
                    },
                    type    : "POST",
                    beforeSend : function(){
                        ali.loader(a.panel, 'show');
                    },
                    success : function ( response ) {

                        if( response ) {
                            $(response).insertAfter( $("#ChildNode-" + current_node_level ).closest("div.form-group") );
                            $('select.selecter').selectpicker('refresh');
                        }

                        ali.loader(a.panel, 'hide');
                    }
                } );
            });
        },

        waitApply : function(){

            var $th = this,
                a = $th.obj;

            $(a.apply).on('click', function(){

                if ( $.trim( $(a.keywords).val() ) == '' && $(a.parent).val() == '0' ) {

                    $(a.keywords).focus().parents( '.inputer' ).addClass( 'inputer-red' );

                    ali.notify( $( '#errorKeywords' ).html() );

                    return false;
                }

                $th.findByNode(1);
            });
        },

        waitText : function () {

            var $th = this,
                a = $th.obj;

            $(a.keywords).on( 'keypress', function () {

                var $inp = $( this ).parents( '.inputer' );

                if ( $inp.hasClass( 'inputer-red' ) )
                    $inp.removeClass( 'inputer-red' );
            } );
        },

        supplier : function(){

            var $th = this,
                a   = $th.obj;

            $(document).on('click', a.supplier, function(){

                var productItem = $( this ).closest( a.rows );
                var productJson = productItem.data( 'json' );
                var productId = $( this ).closest( a.rows ).attr( 'id' );

                if ( !productJson ) {

                    $body.trigger( {
                        type : "modal:load"
                    } );

                    ProductAmazon.getProductInfoFromAmazon( productId, 'showProduct' );

                } else {

                    SupplierInfo.showProduct( productJson );

                }


            });

        },

        supplierInfo : function( data ){

            var $this;
            var $body          = $( "body" );
            var obj            = {
                rows         : '.product-item',
                supplierInfo : '.js-supplier-info',
                btnGoAli     : '.js-modal-go-to-aliexpress',
                slider       : {
                    item    : '.thumb-list li',
                    img     : '.img-main img',
                    imgSku  : '.product-supplier .sku-wrap-img img',
                    itemSku : '.sku-wrap-img'
                }
            };

            $( '#panel-modal' ).find( '.modal-body' ).html(
                ali.objTotmpl( $( '#tmpl-bodyModal' ).text(), data )
            ).modal( 'show' );
        },

        findByNode : function( page ){

            var $th     = this,
                a       = $th.obj,
                $tmpl   = $(a.tmpl).html(),
                $paging = $(a.layout).parent().find( '.pagination-menu' ),
                sort   =  $(a.sort).attr( 'value' );


            var lastChildNodeInfo = AWSImport.getLastChildNodeInfo();
            var node_level = lastChildNodeInfo.nodeLevel;

            if( $("#ChildNode-" + node_level ).val() == "0") {
                node_level = node_level - 1;
            }

            $.ajaxQueue( {
                url     : ajaxurl,
                data    : {
                    action     : 'ali_aws_search_by_node',
                    data       : $(a.form).serializeArray(),
                    page       : page,
                    sort       : sort,
                    node_level : node_level
                },
                type    : "POST",
                beforeSend : function(){
                    ali.loader(a.form, 'show');
                },
                success : function ( response ) {

                    $(a.layout).html('');
                    $paging.html('');

                    ali.loader(a.form, 'hide');

                    response = ali.tryJSON( response );

                    if ( response && response.products != 'undefined' ) {

                        $th.createPagination( $paging, response.totalResults, page );

                        $( '#total-find' ).text( response.totalResults );

                        //console.log( response.products );

                        $.each( response.products, function ( i, p ) {

                            if ( p.already ) {
                                p.btnClass = 'disabled';
                                p.btnIcon  = 'glyphicon-ok';
                                p.rowClass = 'import-success';
                            }
                            else {
                                p.btnClass = '';
                                p.btnIcon  = 'glyphicon-plus';
                                p.rowClass = '';
                            }

                            var send = ali.replace(
                                [ '%numb%', '%imageUrl%', '%productUrl%', '%productTitle%', '%salePrice%', '%AmountSaved%', '%Price%', '%btnClass%', '%btnIcon%', '%rowClass%', '%asin%' ],
                                [ i, p.imageUrl, p.productUrl, p.productTitle, p.salePrice, p.AmountSaved, p.Price, p.btnClass, p.btnIcon, p.rowClass, p.ASIN ],
                                $tmpl
                            );

                            $(a.layout).append( send );
                        } );

                        if ( $( a.results ).is( ':hidden' ) ) {
                            $( a.results ).show( 500 );
                            ali.scrollToNode( a.results );
                        }

                    }
                    else {
                        ali.notify(response.error);
                    }
                }
            } );
        },

        waitSort : function () {

            var $ob = this.obj;

            $( $ob.results ).on( 'click', '.panel-heading [data-target]', function () {

                $( this ).parents( '.btn-group' ).find( '.dropdown-toggle span.name' ).text( $( this ).text() );

                $ob.sort.val( $( this ).data( 'target' ) );

                AWSImport.findByNode( 1 );
            } );

        },

        init : function(){

            $( '[data-target="bulkImport"]' ).on( 'click', function ( e ) {

                var l     = $( '#listProducts' ),
                    items = l.find( 'input:checkbox:checked' );

                if ( items.length == 0 )
                    return false;

                items.each( function () {

                    var btn = $( this ).parents( '.product-item' ).find( '.js-import-product' );

                    if ( !btn.hasClass( 'disabled' ) )
                        btn.click();
                } );
            } );

            var $this = this;

            $this.waitSort();
            $this.changeParentNode();
            $this.changeChildNode();
            $this.waitApply();
            $this.waitText();
            $this.checker();
            $this.supplier();
        }
    };

    AWSImport.init();

    var cover = {
        init : function () {
            $( 'body' ).on( 'modal:show', function () {
                setTimeout( function () {
                    ali.coverHide()
                }, 1000 );
            } );
            $( 'body' ).on( 'modal:load', function () {
                ali.coverShow();
            } );
        }
    };
    cover.init();


    var SupplierInfo = (function () {
        var $this;
        var $body          = $( "body" );
        var $modal         = $( '#panel-modal' );
        var $tmplBodyModal = $( '#tmpl-bodyModal' ).text();
        var obj            = {
            rows         : '.product-item',
            supplierInfo : '.js-supplier-info',
            btnGoAli     : '.js-modal-go-to-aliexpress',
            slider       : {
                item    : '.thumb-list li',
                img     : '.img-main img',
                imgSku  : '.product-supplier .sku-wrap-img img',
                itemSku : '.sku-wrap-img'
            }
        };

        function modalRender( product ) {
            var $html = templateModal( product );
            modalHtml( $html );
        }

        function templateModal( data ) {
            var $html = ali.objTotmpl( $tmplBodyModal, data );
            return $html;
        }

        function modalHtml( $html ) {
            $modal.find( '.modal-body' ).html( $html );
        }

        function initZoom() {
            $( 'body img#zoom' ).elevateZoom( {
                zoomType           : "lens",
                lensShape          : "round",
                borderSize         : 8,
                cursor             : 'crosshair',
                responsive         : true,
                containLensZoom    : true,
                lensSize           : 150,
                borderColour       : 'rgba(193,193,193,0.3)',
                zoomWindowFadeIn   : 500,
                zoomWindowFadeOut  : 750,
                zoomWindowWidth    : 200,
                zoomWindowHeight   : 200,
                gallery            : 'list-thumb',
                galleryActiveClass : 'active'
            } );

            activeZoom();
        }


        function initSlick() {
            $( '.thumb-list' ).slick( {
                slidesToShow   : 4,
                slidesToScroll : 1,
                autoplay       : true,
                autoplaySpeed  : 2000,
                vertical       : true
            } );
        }

        function activeZoom() {
            var gallery = $( '.thumb-list' );
            setTimeout( function () {
                gallery.find( '.item-touch.active' ).click();
            }, 400 );
        }

        function destroyZoom(  ) {
            $('.zoomContainer').remove();
            $( 'body img#zoom' ).removeData('elevateZoom').removeData('zoomImage');
        }

        return {
            showProduct : function ( product ) {

                var m = $modal.find( '.js-modal-add-to-import-list' );
                if ( $( obj.rows + '[data-url*="' + product.id + '"]' ).hasClass( 'import-success' ) ) {
                    m.addClass( 'disabled' ).find( 'span.glyphicon' ).removeClass( 'glyphicon-plus' ).addClass( 'glyphicon-ok' );
                }
                else {
                    m.removeClass( 'disabled' ).find( 'span.glyphicon' ).removeClass( 'glyphicon-ok' ).addClass( 'glyphicon-plus' );
                }

                //product[ 'starRating' ] = parseFloat( product.starOrder.percent ) * 20 + '%';

                modalRender( product );

                $modal.modal( 'show' );
                $body.trigger( {
                    type    : "modal:show",
                    product : product
                } );

            },
            init        : function () {
                $this = this;

                $body.on( 'modal:show', function () {
                    initZoom();
                    initSlick();
                } );

                $( window ).resize( function () {
                    activeZoom();
                } );

                $modal.on( 'hidden.bs.modal', function ( e ) {
                    destroyZoom();

                } );

                $body.on( 'click', obj.slider.item + ',' + obj.slider.itemSku, function () {
                    $( obj.slider.item + ',' + obj.slider.itemSku ).removeClass( 'active' );
                    var src = $( this ).addClass( 'active' ).find( 'img' ).attr( 'src' );
                    $( obj.slider.img ).attr( 'src', src );
                    $( obj.slider.img ).attr( 'data-zoom-image', src );

                    var ez = $( 'img#zoom' ).data( 'elevateZoom' );
                    ez.swaptheimage( src, src );
                } );

                $body.on( 'click', obj.btnGoAli, function () {
                    var linkProduct = $( this ).closest( '.modal-content' ).find( '.product-supplier' ).data( 'url' );
                    //togo backend replace url
                    linkProduct     = linkProduct.replace( 'item//', 'item/a/' );
                    window.open( linkProduct, '_blank' );
                } );

            }
        }

    })();

    SupplierInfo.init();




    var ImportProduct = (function () {
        var $this;
        var $body = $( "body" );
        var obj   = {
            rows     : '.product-item',
            btn      : '.js-import-product',
            btnModal : '.js-modal-add-to-import-list'

        };

        return {
            init : function () {
                $this = this;

                $body.on( 'click', obj.btn, function () {
                    var idProduct = $( this ).closest( obj.rows ).attr( 'id' );

                    $( this ).addClass( 'disabled' ).find( 'span' ).addClass( 'infinite' );
                    ProductAmazon.saveProduct( idProduct );
                } );

                $body.on( 'click', obj.btnModal, function () {
                    var idProduct = $(".product-supplier").data( 'id' );
                    $( this ).addClass( 'disabled' ).find( 'span' ).addClass( 'infinite' );
                    ProductAmazon.saveProduct( idProduct );
                } );

            },
            push : function ( product, saveCompletePromise ) {

                if( typeof product !== "object" ) {
                    console.log( "product is not a object" );
                    return false;
                }

                var id = product.id;
                var catname;
                var fildcat;

                if ($('#dropcat').find(":selected").val() == '0'){

                    catname = $('#parentNodes').find(":selected").text();
                    fildcat = 'name';
                }
                else{
                    catname = $('#dropcat').find(":selected").val();
                    fildcat = 'id';
                }
                product.countries = '';
                product.service   = 'amazon';

                $.ajaxQueue( {
                    url      : ajaxurl,
                    dataType : 'json',
                    data     : {
                        action  : 'ali_product_ali',
                        product : ali.b64EncodeUnicode( JSON.stringify( product ) ),
                        publishstatus: $('#publishstatus').find(":selected").val(),
                        dropcat: catname,
                        fildcat: fildcat
                    },
                    type     : "POST",
                    success  : function ( response ) {

                        console.log( response );

                        $( '#' + id  )
                            .addClass( 'import-success' )
                            .find( obj.btn )
                            .addClass( 'disabled' )
                            .find( 'span.glyphicon' )
                            .removeClass( 'infinite glyphicon-plus' )
                            .addClass( 'glyphicon-ok disabled' );
                        $( '.product-supplier[data-id*="' + id + '"]' ).closest( '.modal-content' ).find( obj.btnModal + ' span.glyphicon' )
                            .removeClass( 'infinite glyphicon-plus' )
                            .addClass( 'glyphicon-ok' );


                        saveCompletePromise.resolve();

                    }, error  : function ( err ) {

                        console.log( err );
                        saveCompletePromise.reject();

                    }
                } );
            }
        }

    })();

    ImportProduct.init();


    /* AMAZON Product */
    var ProductAmazon = (function () {

        var obj = {
            rows : '.product-item',
            btn      : '.js-import-product',
            btnModal : '.js-modal-add-to-import-list'
        };

        var activeImportNow = false;
        var savingProductsList = [];

        function getDataProduct( idProduct ) {
            return $( '#' + idProduct ).data( 'json' );
        }

        function getProductInfo( idProduct ) {

            var productJson = getDataProduct( idProduct );

            if ( productJson ) {

                savingProductsList.push( productJson );

                if( !activeImportNow ) {
                    ProductAmazon.saveProductsList();
                }

            } else {

                ProductAmazon.getProductInfoFromAmazon( idProduct, 'saveProduct' );

            }

        }


        return {
            saveProductsList : function () {

                if( savingProductsList.length == 0 ) return false;

                activeImportNow = true;
                var productIsSaved = new $.Deferred();
                var currentProduct = $( obj.rows + '[data-url*="' + savingProductsList[0].url + '"]' );

                ImportProduct.push( savingProductsList[0], productIsSaved );

                $.when( productIsSaved ).then(function() {

                    // UI итема изменяем
                    currentProduct
                        .addClass( 'import-success' )
                        .find( obj.btn )
                        .addClass( 'disabled' )
                        .find( 'span.glyphicon' )
                        .removeClass( 'infinite glyphicon-plus' )
                        .addClass( 'glyphicon-ok disabled' );

                    console.log( "Saved ASIN(Id) - " + savingProductsList[0].id );
                    savingProductsList.splice(0, 1);

                    if( savingProductsList.length > 0 ) {
                        ProductAmazon.saveProductsList();
                    } else {
                        activeImportNow = false;
                    }

                }, function() {

                    console.log( "Saving product Error (Promise Error)" );

                    if( savingProductsList.length > 0 ) {
                        ProductAmazon.saveProductsList();
                    } else {
                        activeImportNow = false;
                    }

                });
            },
            saveProduct : function ( idProduct ) {
                getProductInfo( idProduct );
            },
            getProductInfoFromAmazon : function ( id, callbackInfo ) {

                (function( id, callbackInfo ) {
                    $.ajaxQueue({
                    url: ajaxurl,
                    data: {
                        action : 'ali_aws_get_product',
                        asin   : id // asin
                    },
                    type: "POST",
                    success: function (response) {

                        console.log( "--- Product Info ---" );
                        console.log( JSON.parse(response) );
                        //return false;

                        var correctProductJson = getCorrectProductJson( JSON.parse(response) );

                        $( '#' + correctProductJson.id ).data('json', correctProductJson);

                        function getCorrectProductJson($obj) {

                            var data = {
                                url: "",
                                id: "", // ASIN
                                title: "",
                                imgs: [],
                                quantity: "",
                                wishlist: "",
                                shopLink: "",
                                shopLinkFeedback: "",
                                numberReviews: "",
                                shopName: "",
                                rankNum: "",
                                shopTime: "",
                                storeRank: "",
                                storeRankTitle: "",
                                storePositivePercent: "",
                                sku: [],
                                params: [],
                                packaging: {},
                                skuProducts: [],
                                prices: {
                                    minPrice: "",
                                    maxPrice: "",
                                    actMinPrice: "",
                                    actMaxPrice: ""
                                },
                                starOrder: {
                                    percent: "",
                                    rantings: ""
                                },
                                lotNumeric: "",
                                orders: "",
                                feedbackUrl: "",
                                description: "",
                                currencyCode: ""
                            };



                            data.url = $obj.url;
                            data.id = $obj.asin;
                            data.title = $obj.title[0];
                            data.imgs = getImagesObj($obj.images);
                            data.params = getFeaturesObj($obj.features);
                            data.packageDimensions = getPackageDimensionsObj($obj.packageDimensions);
                            data.prices.minPrice = $obj.price;
                            data.prices.maxPrice = $obj.price;
                            data.prices.actMinPrice = $obj.salePrice;
                            data.prices.actMaxPrice = $obj.salePrice;
                            data.packageQuantity = getPackageQuantityObj($obj.packageQuantity);
                            data.feedbackUrl = $obj.feedbackUrl[0];
                            data.description = getDescriptionObj($obj.description);
                            data.currencyCode = $obj.currencyCode[0];
                            // The 'Brand' does not participate in the product saving now
                            data.brand = $obj.brand[0];

                            return data;
                        }

                        function getPackageDimensionsObj( $packageDimensions ) {

                            var result = [];

                            for (var i = 0, len = $packageDimensions.length; i < len; i++) {

                                var packageDimension = {};

                                for (var key in $packageDimensions[i]) {

                                    if ($packageDimensions[i].hasOwnProperty(key)) {
                                        packageDimension.name = key;
                                        packageDimension.value = $packageDimensions[i][key];
                                    }

                                }

                                result.push( packageDimension );
                            }

                            return result;
                        }

                        function getFeaturesObj( $features ) {

                            var result = [];

                            for (var i = 0, len = $features.length; i < len; i++) {

                                var feature = {};

                                feature.name = 'Feature';
                                feature.value = $features[i];

                                result.push( feature );
                            }

                            return result;
                        }

                        function getImagesObj( $arr ) {

                            var imagesArr = [];

                            for ( var i = 0, len = $arr.length; i < len; i++ ) {

                                var img = {};

                                img.url = $arr[i].LargeImage;
                                img.alt = '';

                                imagesArr.push( img );
                            }

                            return imagesArr;
                        }

                        function getDescriptionObj( $desc ) {

                            var result = '';

                            if ($desc !== '') {
                                result = $desc[0];
                            }

                            return result;
                        }

                        function getPackageQuantityObj( $packageQuantity ) {

                            var result = '';

                            if ($packageQuantity !== '') {
                                result = $packageQuantity[0];
                            }

                            return result;
                        }

                        if( callbackInfo == "showProduct" ) {
                            SupplierInfo.showProduct( correctProductJson );
                        } else if ( callbackInfo == "saveProduct" ) {
                            ProductAmazon.saveProduct( correctProductJson.id );
                        }


                        //$('#test').html(response); // print xml
                        //console.log("print xml for a item");

                    },
                    error: function (err) {

                        console.log(err);
                        console.log("Request product info to \"www.amazon.com\" error, please, try again");

                        if( callbackInfo == "showProduct" ) {
                            ali.coverHide();
                        } else if ( callbackInfo == "saveProduct" ) {
                            // Another attempt to add a product to the save queue
                            ProductAmazon.saveProduct( id );
                        }
                    }
                });
                }( id, callbackInfo ));



            }
        }
    })();



});
