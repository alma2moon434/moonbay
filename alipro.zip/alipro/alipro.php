<?php
/**
 *	Plugin Name: AliPlugin Pro
 *	Plugin URI: https://alipartnership.com/
 *	Description: AliPlugin Pro is a WordPress plugin created for AliExpress affiliate program
 *	Version: 1.2.4
 *	Text Domain: ali
 *	Domain Path: /lang
 *	Requires at least: WP 4.8.1
 *	Author: V. Kukin & Y. Nevskiy & G. Supiev
 *	Author URI: http://yellowduck.me/
 *	License: SHAREWARE
 */

if ( !defined( 'ALI_VERSION' ) ) define( 'ALI_VERSION', '1.2.4' );
if ( !defined( 'ALI_PATH' ) ) define( 'ALI_PATH', plugin_dir_path( __FILE__ ) );
if ( !defined( 'ALI_URL' ) ) define( 'ALI_URL', str_replace( array('https:', 'http:'), '', plugins_url('alipro') ) );
if ( !defined( 'ALI_CODE' ) ) define( 'ALI_CODE', 'ion' );
if ( !defined( 'ALI_ERROR' ) ) define( 'ALI_ERROR', ali_check_server() );

function ali_check_server() {

	if( '5.6' > PHP_VERSION )
		return __( 'PHP Version is not suitable. You need version 5.6+', 'ali' ) .
		       '. <a href="https://alipartnership.com/codex/system-requirements/" target="_blank">Learn more</a>.';

	$extensions = get_loaded_extensions();

	$key = ALI_CODE != 'ion' ? 'Zend Guard Loader' : 'ionCube Loader';

	if ( ! in_array($key, $extensions) ) {

		return sprintf( __( '%s Not found', 'ali' ), $key ) .
		       '. <a href="https://alipartnership.com/codex/how-to-install-ioncube-loader-on-hosting/" target="_blank">Learn more</a>.';
	}

	return false;
}

function ali_admin_notice__error() {

	$check = ali_check_server();

	if( $check ) {

		$class = 'notice notice-error';
		$message = __( 'Error!', 'ali' ) . ' ' . $check;

		printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
	}
}
add_action( 'admin_notices', 'ali_admin_notice__error' );

if( is_admin() ) :

	require( ALI_PATH . 'core/setup.php' );

	register_activation_hook( __FILE__, 'ali_install' );
	register_uninstall_hook( __FILE__, 'ali_uninstall' );
	register_activation_hook( __FILE__, 'ali_activate' );

endif;

if( ! ALI_ERROR ) {

	require( ALI_PATH . 'core/core.php' );
	require( ALI_PATH . 'core/update.php' );
	require( ALI_PATH . 'core/init.php' );
	require( ALI_PATH . 'admin/cron.php' );

	if ( is_admin() ) :
		require( ALI_PATH . 'core/controller.php' );
	endif;
}
