<?php

/**
 * Setup the plugin
 */
function ali_install(){
	ali_maybe_add_columns();
	require( ALI_PATH . 'core/sql.php' );

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	foreach(ali_sql_list() as $key){
		dbDelta($key);
    } 


	update_site_option( 'ali-version', ALI_VERSION  );
	add_rewrite_rule( '^oauth1/extension/?$','index.php?rest_oauth1=extension','top' );

	flush_rewrite_rules();

}
function ali_maybe_add_columns() {
	
	global $wpdb;
	$wpdb->query("RENAME TABLE `{$wpdb->prefix}ali_affiliate` TO `{$wpdb->prefix}ali_ali_meta`");
	
	$args = [
		'ali_ali_meta' => [
			'services'    => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `services` VARCHAR(40) DEFAULT 'aliexpress';",
			'skuOriginal' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `skuOriginal` LONGTEXT DEFAULT NULL;",
			'adminDescription' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `adminDescription` TEXT DEFAULT NULL;",
			'skuOriginaAttr' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `skuOriginaAttr` LONGTEXT DEFAULT NULL;",
			'currencyCode' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `currencyCode` char(4) DEFAULT NULL;",
			'origPrice' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `origPrice` decimal(10,2) DEFAULT NULL;",
			'origPriceMax' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `origPriceMax` decimal(10,2) DEFAULT NULL;",
			'origSalePrice' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `origSalePrice` decimal(10,2) DEFAULT NULL;",
			'origSalePriceMax' => "ALTER TABLE `{$wpdb->prefix}ali_ali_meta` ADD `origSalePriceMax` decimal(10,2) DEFAULT NULL;"
		],	  	    
	];
	
	foreach( $args as $key => $val ) {
		
		$result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
			 	 FROM `information_schema`.`COLUMNS`
			 	 WHERE `TABLE_SCHEMA` = '%s' AND `TABLE_NAME` = '{$wpdb->prefix}{$key}'",
				DB_NAME
			)
		);
		
		$col = [];
		if( count( $result ) > 0 ) foreach( $result as $column ) {
			$col[] = $column->COLUMN_NAME;
		}
		
		if( count( $col ) > 0 ) foreach( $val as $k => $v ) {
			if( ! in_array( $k, $col ) )
				$wpdb->query( $v );
		}
	}
}

/**
 * Uninstall plugin
 */
function ali_uninstall(){}

/**
 * Check installed plugin
 */
function ali_installed(){

	if ( !current_user_can('install_plugins') ) return;

	if ( get_site_option('ali-version') < ALI_VERSION )
		ali_install( );
}
add_action( 'admin_menu', 'ali_installed' );

/**
 * When activate plugin
 */
function ali_activate(){

	ali_installed();

	do_action( 'ali_activate' );
}

/**
 * When deactivate plugin
 */
function ali_deactivate(){

	do_action( 'ali_deactivate' );
}