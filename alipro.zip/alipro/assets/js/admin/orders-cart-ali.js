/**
 * Created by pavel on 29.06.2016.
 */

jQuery( function ( $ ) {

	var parseCart = function ( obj ) {
		var cart = {
				quantity      : '',
				priceItems    : '',
				priceShipping : '',
				total         : '',
				shipTo        : '',
				group         : {
					seller        : '',
					priceItems    : '',
					priceShipping : '',
					total         : '',
					items         : []
				}
			},
			item = {
				img            : '',
				title          : '',
				quantity       : '',
				priceItem      : '',
				priceShipping  : '',
				total          : '',
				deliveryTime   : '',
				processingTime : '',
				methodShipping : ''
			};

		cart.quantity = obj.find('#promotional-item-notification .main-title-text-num').text();
		cart.priceShipping = obj.find('.bottom-info-right-wrapper li:eq(1) .default-price').text();
		cart.total = obj.find('.bottom-info-right-wrapper .total-price.ui-cost').text();
		cart.shipTo = obj.find('.link-fake-selector .country-text').text();

		var group = obj.find( 'table.item-group' );

		return cart;
	};

	var orderCartAli = (function () {
		var $this,
			$body = $( 'body' );

		var obj = {
			panelItemOrder : $( '#panel-item-order' )
		};

		var tmpl = {
			cartAli : $( '#tmpl-cart-ali' ).html()
		};

		function getCartAli() {

			var cartAli = new Promise( function ( resolve, reject ) {
				window.ali.aliExpansion.addTask( 'http://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm', resolve, this, 'cart' );
			} );

			cartAli.then( function ( result ) {
				$body.trigger( {
					type : "cartAli:data",
					info : parseCart( result.obj )
				} );
			} );
		}

		function renderCart( info ) {
			obj.panelItemOrder.find( '.pull-right' ).html( ali.objTotmpl( tmpl.cartAli, info ) );
		}


		return {
			init : function () {
				$this = this;
				getCartAli();

				$body.on( 'cartAli:data', function ( data ) {
					renderCart( data.info )
				} );
			}
		}

	})();
	orderCartAli.init();
} );