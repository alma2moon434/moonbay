/**
 * Created by pavel on 17.05.2016.
 */

jQuery( function ( $ ) {
	window.ali = window.ali || {
			tryJSON : function ( data ) {
				try {
					var response = $.parseJSON( data );
				}
				catch ( e ) {
					console.log( data );
					return false;
				}

				return response;
			}
		};
	'use strict';

	window.aliCart = (function () {
		var $this;
		var $body     = $( 'body' );
		var cb_update = function ( data ) {
			var obj = ali.tryJSON( data );
			if ( obj ) {
				$( 'body' ).trigger( {
					type : "cart:update",
					cart : obj
				} );
			}
		};

		var cb_change = function ( data, order_id ) {
			//console.log( arguments );
			var obj = ali.tryJSON( data );
			if ( obj ) {
				$( 'body' ).trigger( {
					type     : "cart:change",
					cart     : obj,
					order_id : order_id
				} );
			}
		};

		var add_order = function ( data, order ) {
			//console.log( arguments );
			var obj = ali.tryJSON( data );
			if ( obj ) {
				$( 'body' ).trigger( {
					type  : "cart:add",
					cart  : obj,
					order : order,
					info  : { order_id : obj.info.change_order }
				} );
			}
		};

		return {
			init           : function ( el ) {
				$this           = this;
				$this.$discount = '[name="discount"]';
				$body.on( 'cart:update', function ( e ) {
					/*	console.log( 'aliCart:update' );
					 console.log( e.cart );*/
				} );

				$body.on( 'cart:update', function ( e ) {
					//	console.log( 'aliCart:change' );
					// console.log( e.cart );
				} );

				$body.on( 'cart:add', function ( e ) {
					/*	console.log( 'aliCart:add' );
					 console.log( e.cart );
					 console.log( e.order );*/
				} );
				$body.on( 'cart:change', function ( e ) {
					/*	console.log( 'cart:change' );
					 console.log( e.cart );
					 console.log( e.order_id );*/
				} );

				$this.load();
			},
			newQuantity    : function ( order_id, quantity ) {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						discount    : aliCart.getDiscount(),
						action      : "ads_actions_basket",
						ads_actions : "set_quantity",
						order_id    : order_id,
						quantity    : quantity
					},
					success : function ( data ) {
						cb_change( data, order_id );
					}
				} );
			},
			newShipping    : function ( order_id, shipping ) {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						discount    : aliCart.getDiscount(),
						action      : "ads_actions_basket",
						ads_actions : "set_shipping",
						order_id    : order_id,
						shipping    : shipping
					},
					success : function ( data ) {
						cb_change( data, order_id );
						//console.log( arguments );
						var obj = ali.tryJSON( data );
						if ( obj ) {
							$( 'body' ).trigger( {
								type : "cart:shipping",
								cart : obj,
								info : {
									order_id : obj.info.change_order
								}
							} );
						}
					}
				} );
			},
			add            : function ( order ) {
				var data = $.extend( {
					id        : '',
					quantity  : 1,
					variation : '',
					title     : ''
				}, order );

				data.action      = "ads_actions_basket";
				data.ads_actions = "add";
				data.discount    = aliCart.getDiscount();
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : data,
					success : function ( data ) {
						add_order( data, order );
					}
				} );
			},
			remove         : function ( order_id ) {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						discount    : aliCart.getDiscount(),
						action      : "ads_actions_basket",
						ads_actions : "remove",
						order_id    : order_id
					},
					success : cb_update
				} );
			},
			load           : function () {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						discount    : aliCart.getDiscount(),
						action      : "ads_actions_basket",
						ads_actions : "get_orders"
					},
					success : cb_update
				} );
			},
			convPrice      : function ( v, callback ) {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						action   : "ali_conv_price",
						price    : v[ 0 ],
						currency : v[ 1 ]
					},
					success : callback
				} );
			},
			convPriceTotal : function ( v, callback ) {
				$.ajax( {
					url     : alidAjax.ajaxurl,
					type    : "POST",
					async   : true,
					data    : {
						action            : "ali_conv_price_total",
						price             : v.price,
						currency          : v.currency,
						price_shipping    : v.price_shipping,
						currency_shipping : v.currency_shipping,
						quantity          : v.quantity
					},
					success : callback
				} );
			},
			getDiscount    : function () {
				var $discount = $( $this.$discount );
				if ( $discount.length ) {
					return $discount.val();
				}
				return '';
			}
		};

	})();

	$( aliCart.init() );
} )
;



