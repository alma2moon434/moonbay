function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

function sendAbandonedEmail(email) {
    jQuery.ajax({
        url: alidAjax.ajaxurl,
        type: "POST",
        data: {
            action: "ali_action_abandoned",
            abandonedEmail: email
        },
        dataType: "json",
        success: function(xhr) {
        },
        error: function (xhr) {
        }
    });
}

jQuery(function($) {
    var typingTimer;
    var email;

    $('#email').on('input', function () {
        email = $(this).val();
        if (isEmail(email)) {
            clearTimeout(typingTimer);
            typingTimer = setTimeout(
                sendAbandonedEmail.bind(null, email),
                5000
            );
        }
    });
});