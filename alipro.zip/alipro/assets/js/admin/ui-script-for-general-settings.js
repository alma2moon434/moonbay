/**
 * Created by Dmitriy Gavrilov on 08.02.2017.
 */


jQuery( function ( $ ) {

	var ui_select = $( "#ui_select_program" );
	var ui_select_value_indicator = $( "#ui_select_program+.selecter>button" );
	var ui_select_value = '';

	var programsFields = {
		AppKey 			: $( '#AppKey' ).closest(' .form-group '),
		trackingId  : $( '#trackingId' ).closest(' .form-group '),
		Cashback		: $( '#affiliateUrl' ).closest(' .form-group ')
	};

	programsFields.Cashback.css({'display' : 'none'});
	
	ui_select_value = ui_select_value_indicator.attr( 'title' );
		if( ui_select_value == 'Portals Aliexpress' ) {
			programsFields.Cashback.css({'display' : 'none'});
			programsFields.trackingId.fadeIn();
			programsFields.AppKey.fadeIn();
			
		} else {
			programsFields.Cashback.fadeIn();

			programsFields.trackingId.css({'display' : 'none'});
			programsFields.AppKey.css({'display' : 'none'});

		}
	ui_select.change(function() {

		ui_select_value = ui_select_value_indicator.attr( 'title' );

		if( ui_select_value == 'Portals Aliexpress' ) {
			programsFields.Cashback.css({'display' : 'none'});
			programsFields.trackingId.fadeIn();
			programsFields.AppKey.fadeIn();
			
		} else {
			programsFields.Cashback.fadeIn();

			programsFields.trackingId.css({'display' : 'none'});
			programsFields.AppKey.css({'display' : 'none'});

		}

	});

} );
