/**
 * Created by Vitaly on 07.04.2016.
 */

jQuery(function($){

    ChartsFlot.init();

    window.Sales = {

        request : function(method, callback){

            var from = $('#date-from').val(),
                to   = $('#date-to').val();

            $.ajaxQueue( {
                url     : ajaxurl,
                data    : {
                    action : 'ali_sales_data',
                    from   : from,
                    to     : to,
                    method : method
                },
                type    : "POST",
                success : callback
            });
        },
        chartData : function(a){

            if( typeof $(a) == 'undefined' ) return false;

            ali.loader(a,'show');

            var method = $(a).data('method');

            this.request(method, function(data){
                $(a).parent().find('.chart_data').text(data);
                ChartsFlot.chartReloader(a);
                ali.loader(a,'hide');
            });
        },
        totalRevenue : function(){

            var a = '#stat-sales';

            if( typeof $(a) == 'undefined' ) return false;

            ali.loader(a,'show');

            this.request('sales', function(data){

                data = ali.tryJSON(data);

                if( data ){

                    $(a).html('');

                    $.each(data, function(i, v){
                        $(a).append(
                            '<div class="row item-' + i + '">' +
                            '<div class="col-md-30">' + v.title + '</div>' +
                            '<div class="col-md-30"><h3>' + v.count + '</h3></div>' +
                            '</div>'
                        );
                    });
                }
                ali.loader(a,'hide');
            });
        },

        bigTable : function(a, method){

            if( typeof $(a) == 'undefined' ) return false;

            ali.loader(a,'show');
            this.request(method, function(data){

                data = ali.tryJSON(data);

                if( data ){

                    var $tbody = $(a).find('tbody'),
                        n  = 1;

                    $tbody.html('');

                    $.each(data, function(i, v){

                        ali.newRow($tbody, [n, v.title, v.count]);
                        n++;
                    });
                }

                ali.loader(a,'hide');
            });
        },

        bigTable3 : function(a, method){

            if( typeof $(a) == 'undefined' ) return false;

            ali.loader(a,'show');
            this.request(method, function(data){

                data = ali.tryJSON(data);

                if( data ){

                    var $tbody = $(a).find('tbody'),
                        n  = 1;

                    $tbody.html('');

                    $.each(data, function(i, v){

                        ali.newRow($tbody, [n, v.title, v.email, v.count]);
                        n++;
                    });
                }

                ali.loader(a,'hide');
            });
        },
        dateRangePicker:function(a){

            if( typeof $(a) == 'undefined' ) return false;

            $(a).find('span').html(
                moment().subtract(29,'days').format('MMMM D, YYYY')+' - '+ moment().format('MMMM D, YYYY')
            );
            $(a).daterangepicker({
                startDate:moment().subtract(29,'days')
            });

            $(a).on('apply.daterangepicker',function(ev, picker){
                $(this).find('span').html(picker.startDate.format('MMMM D, YYYY') + ' - ' + picker.endDate.format('MMMM D, YYYY'));
                $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));

                $('#date-from').val(picker.startDate.format('YYYY-MM-DD'));
                $('#date-to').val(picker.endDate.format('YYYY-MM-DD'));

                Sales.totalRevenue();
                Sales.chartData('.ali-orders');
                Sales.bigTable('#top5-products', 'products-amount');
                Sales.bigTable3('#top5-customers', 'customers-amount');
                Sales.bigTable('#top5-categories', 'categories-amount');
            });
        },
        init : function(){
            this.dateRangePicker('.bootstrap-daterangepicker-dropdown');
            this.totalRevenue();
            this.chartData('.ali-orders');
            this.bigTable('#top5-products', 'products-amount');
            this.bigTable3('#top5-customers', 'customers-amount');
            this.bigTable('#top5-categories', 'categories-amount');
        }
    };

    Sales.init();

    $('.chart-view').on('click', '[data-target]', function(e){
        e.preventDefault();
        $(this).parents('.btn-group').find('.dropdown-toggle span.name').text($(this).text());
        $('.ali-orders').data('method', $(this).data('target'));
        Sales.chartData('.ali-orders');
    });

    $('.stats-table').on('click', '[data-target]', function(e){
        e.preventDefault();
        $(this).parents('.btn-group').find('.dropdown-toggle span.name').text($(this).text());

        var id = $(this).parents('.panel').find('.bigTable').attr('id'),
            method = $(this).data('target');

        Sales.bigTable('#'+id, method);
    });

   /* $('.bigTable').on('click', 'thead a', function(e){
        e.preventDefault();

        var $a = $(this).parents('.bigTable');
        var sort   = $(this).hasClass('desc') ? 'asc' : 'desc',
            sortby = $(this).data('of'),
            method = $a.data('method');

        $(this).removeClass('desc asc').addClass(sort);
        $a.data({sort:sort, sortby:sortby});

        Sales.bigTable('#'+$a.attr('id'), method, 1);
    });*/
});