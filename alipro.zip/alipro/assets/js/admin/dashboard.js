/**
 * Created by Vitaly Kukin on 26.03.2016.
 */
jQuery(function($){
    ChartsFlot.orders('.ali-orders');
    ChartsFlot.orders('.ali-graph');
});