/**
 * Created by pavel on 17.05.2016.
 */
jQuery( function ( $ ) {

	var coupon = {
		init  : function () {
			$( 'body' ).on( 'click','.js-coupon__btn', this.send );
		},
		send  : function (e) {
			e.preventDefault();
			var v = $( '.b-coupon [name="discount"]' ).val();
			if ( v != '' ) {
				$( '.b-coupon__msg' ).hide();
				coupon.check( v, function ( message ) {
					$( '.b-coupon__msg--valid' ).show();
					$( '.b-coupon [name="discount"]' ).removeClass('error');
					$( '.b-coupon [name="discount"]' ).addClass('success');
					aliCart.load();
				}, function ( message ) {
					if ( message == 'Discount is not valid' ) {
						$( '.b-coupon__msg--err' ).show();
						$( '.b-coupon [name="discount"]' ).removeClass('success');
						$( '.b-coupon [name="discount"]' ).addClass('error');
						aliCart.load();
					}
				} );

			}
			return false;
		},
		check : function ( value, callback, callbackEr ) {
			$.ajax( {
				url     : alidAjax.ajaxurl,
				type    : "POST",
				async   : true,
				data    : {
					action   : "ads_actions_basket",
					ads_actions : "discount_check",
					discount : value.trim()
				},
				success : function ( data ) {
					console.log(data);
					var obj = ali.tryJSON( data );
					if ( obj.type == 'DiscountTrue' )
						callback( obj.message );
					else
						callbackEr( obj.message );
				}
			} );
		}
	};

	$( coupon.init() );

});