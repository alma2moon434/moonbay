/**
 * Created by Vitaly on 07.07.2016.
 */
jQuery(function($){

    $(document).on('change', '#type', function(){

        var t = $(this).val();

        $.ajax( {
            url     : ajaxurl,
            data    : {
                action : 'ali_get_payments_settings',
                type   : t
            },
            type    : "POST",
            success : function ( response ) {
                if( response != '' ){
                    $('#cc').html(response);

                    $(document).find('#type').selectpicker('render');
                }
            }
        } );
    });
});
