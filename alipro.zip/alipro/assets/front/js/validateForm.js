/**
 * Created by pavel on 17.05.2016.
 */
jQuery( function ( $ ) {


	'use strict';
	$.fn.validateForm = function ( options ) {

		var options = $.extend( {
			classValid         : 'js-valid',
			classInvalid       : 'js-invalid',
			classInvalidEmpty  : 'js-invalid_empty',
			classNotifiInvalid : 'js-notifi_invalid',
			item               : '[required="required"]:not("select"):visible',
			fieldsValid        : {
				full_name    : {
					minLen : 2
				},
				phone_number : {
					minLen : 6,
					number : 'd'
				},
				exp_year     : {
					minLen : 4,
					maxLen : 4
				},
				cvv          : {
					maxLen : 4,
					minLen : 3,
					number : 'd'
				},
				number       : {
					card         : 'card'
				}
			},
			validAll           : {
				minLen : 2,
				maxLen : 60
			},
			msg                : {
				emptyField  : 'This field is required',
				formatField : 'Invalid:{{1}}'
			}


		}, options );

		var validate = {
			email : function ( obj ) {
				var email = $( obj ).val();
				var re    = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test( email );
			},

			minLen : function ( obj, len ) {
				return $( obj ).val().length >= len;
			},

			maxLen : function ( obj, len ) {
				return $( obj ).val().length <= len;
			},
			empty  : function ( obj ) {
				return $( obj ).val().length != '';
			},
			number : function ( obj, type ) {
				if ( type == 'd' ) {

					var val  = $( obj ).val();
					var val1 = val.replace( /\D+/g, "" );
					$( obj ).val( val1 );

					return val == val1;
				}

				return false;
			},
			card   : function ( obj ) {

				var arr         = [],
					card_number = $( obj ).val().toString();

				card_number = card_number.replace( /\D+/g, "" );
				var mask    = card_number.replace( /(\d{4})/g, "$& " );
				mask        = mask.trim();

				$( obj ).val( mask );

				var len = [ 13, 14, 15, 16, 17, 18, 19, 20 ];

				return len.indexOf( card_number.length ) != -1;
			}

		};

		var th = $( this );

		var setValidate = function () {
			th.on( 'keyup', options.item, function ( e ) {
				var ignore = [ 37, 39, 8, 46, 32 ];

				if ( ignore.indexOf( e.keyCode ) !== -1 )
					return;
				var obj = this;

				var err = checkField( obj );

				if ( err == 0 ) {
					renderValid( obj );
				} else {
					renderClear( obj )
				}

				if ( err == 0 ) {
					return true;
				}
			} );
			th.on( 'blur change', options.item, function () {
				var obj = this;
				var err = checkField( obj );

				if ( err == 0 ) {
					renderValid( obj );
				} else if ( err == 'empty' ) {
					renderInvalidEmpty( obj );
				} else {
					renderInValid( obj );
				}

				if ( err == 0 ) {
					return true;
				}
			} );

			th.attr( 'novalidate', 'novalidate' )

				.on( 'submit', function () {
					var errAll   = 0;
					var errFirst = false;
					$( th ).find( options.item ).each( function ( i, obj ) {
						var err = checkField( obj );

						if ( err == 0 ) {
							renderValid( obj );
						} else if ( err == 'empty' ) {
							errAll++;
							renderInvalidEmpty( obj );
						} else {
							errAll++;
							renderInValid( obj );
						}

						if ( errAll === 1 && !errFirst ) {
							errFirst = obj;
							scrollToFinds( obj );
						}

					} );

					if ( errAll === 0 )
						return true;

					return false;

				} )

		};

		function checkField( obj ) {
			var err       = 0;
			var nameField = $( obj ).attr( 'name' );
			var typeField = $( obj ).attr( 'type' );

			var validateEmpty = validate[ 'empty' ]( obj );
			if ( !validateEmpty )
				return 'empty';


			if ( options.fieldsValid[ nameField ] !== undefined ) {
				$.each( options.fieldsValid[ nameField ], function ( name, value ) {
					err += !validate[ name ]( obj, value );
				} );
			} else {
				$.each( options.validAll, function ( i, e ) {
					err += !validate[ i ]( obj, e );
				} );
			}

			if ( validate[ typeField ] !== undefined ) {
				err += !validate[ typeField ]( obj );
			}

			return err;
		}

		function renderInvalidEmpty( obj ) {
			renderInvalidNotifi( obj, options.msg.emptyField )
			$( obj ).parent().addClass( options.classInvalidEmpty );
		}

		function renderInvalidNotifi( obj, str ) {
			$( obj ).parent().children( '.' + options.classNotifiInvalid ).text( str ).show();
		}

		function renderClear( obj ) {
			$( obj ).parent().removeClass( options.classInvalidEmpty + ' ' + options.classInvalid ).removeClass( options.classValid ).children( '.' + options.classNotifiInvalid ).hide();
		}

		function renderValid( obj ) {
			renderClear( obj );
			$( obj ).parent().addClass( options.classValid );
		}

		function renderInValid( obj ) {
			renderClear( obj );
			var str   = options.msg.formatField;
			var label = $( obj ).parent().parent().children( 'label' ).text();
			str       = str.replace( '{{1}}', label );
			str       = clearStr( str );

			renderInvalidNotifi( obj, str );
			$( obj ).parent().addClass( options.classInvalid );
			$( obj ).parent().children( '.' + options.classNotifiInvalid ).show();
		}

		function clearStr( str ) {
			str = str.replace( '*', '' );
			str = str.replace( /\s{2,}/mig, ' ' );
			str = str.trim();
			str = str.replace( /(:)$/mig, '' );
			return str;
		}

		function scrollToFinds( obj ) {
			$( obj ).focus();
			var top = $( obj ).offset().top - 100;
			$( 'body,html' ).stop().animate( {
				scrollTop : top
			}, 1000 );
		}

		return this.each( setValidate );
	};

	$( '#form_delivery' ).validateForm();

} )
;