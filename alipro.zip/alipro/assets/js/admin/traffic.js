/**
 * Created by Vitaly on 07.04.2016.
 */

jQuery(function($){

    ChartsFlot.init();

    window.Traffic = {

        request : function(method, sort, sortby, index, callback){

            var from = $('#date-from').val(),
                to   = $('#date-to').val();

            $.ajaxQueue( {
                url     : ajaxurl,
                data    : {
                    action : 'ali_ga_data',
                    from   : from,
                    to     : to,
                    method : method,
                    sort   : sort,
                    sortby : sortby,
                    index  : index
                },
                type    : "POST",
                success : callback
            });
        },
        createPagination: function (obj, total, current) {

            var $obj = $(obj).parents('.panel-body').find('.pagination-menu'),
                perPage = 10;

            $obj.pagination({
                items: parseInt(total),
                itemsOnPage: parseInt(perPage),
                currentPage: parseInt(current),
                cssStyle: "light-theme",
                prevText: $obj.data('prev'),
                nextText: $obj.data('next'),

                onPageClick: function (pageNumber) {

                    var a = $obj.parents('.panel-body').find('.bigTable').attr('id');
                    Traffic.bigTable('#'+a, $('#'+a).data('method'), pageNumber);
                }
            });
        },
        chartData : function(a){

            if( typeof $(a) == 'undefined' ) return false;

            aliplugin.loader(a,'show');

            var method = $(a).data('method');

            this.request(method, '', '', 1, function(data){
                $(a).parent().find('.chart_data').text(data);
                ChartsFlot.chartReloader(a);
                aliplugin.loader(a,'hide');
            });
        },
        totalTraffic : function(){

            var a = '#stat-traffic';

            if( typeof $(a) == 'undefined' ) return false;

            aliplugin.loader(a,'show');

            this.request('overview', '', '', 1, function(data){

                data = aliplugin.tryJSON(data);

                if( data ){

                    $(a).html('');

                    $.each(data, function(i, v){
                        $(a).append(
                            '<div class="row item-' + i + '">' +
                            '<div class="col-md-30">' + v.title + '</div>' +
                            '<div class="col-md-30"><h3>' + v.count + '</h3></div>' +
                            '</div>'
                        );
                    });
                }
                aliplugin.loader(a,'hide');
            });
        },

        bigTable : function(a, method, index){

            if( typeof $(a) == 'undefined' ) return false;

            var sort   = (typeof $(a).data('sort') != 'undefined') ? $(a).data('sort') : '',
                sortby = (typeof $(a).data('sortby') != 'undefined') ? $(a).data('sortby') : '';

            aliplugin.loader(a,'show');
            this.request(method, sort, sortby, index, function(data){

                data = aliplugin.tryJSON(data);

                if( data ){
                    
                    var meta  = data.meta,
                        main  = data.data,
                        $tbody = $(a).find('tbody');

                    $tbody.html('');
                    aliplugin.newRow($tbody, ['', '', meta.p1t, meta.p2t, meta.p3t, meta.p4t, meta.p5t]);

                    var p  = parseInt(meta.ind)*10 - 9,
                        st = parseInt(meta.ind)*parseInt(meta.lim),
                        s  = p,
                        t  = parseInt(meta.t),
                        n  = p;

                    if( st > t ){
                        s = p + st - t;
                    }

                    $.each(main, function(i, v){

                        if( p >= s ){
                            aliplugin.newRow($tbody, [n, v.p1, v.p2, v.p3, v.avg, v.newvisits, v.bounceRate]);
                            n++;
                        }

                        p++;
                    });
                }

                Traffic.createPagination(a, meta.t, meta.ind);
                aliplugin.loader(a,'hide');
            });
        },
        dateRangePicker:function(a){

            if( typeof $(a) == 'undefined' ) return false;

            $(a).find('span').html(
                moment().subtract(29,'days').format('MMMM D, YYYY')+' - '+ moment().format('MMMM D, YYYY')
            );
            $(a).daterangepicker({
                startDate:moment().subtract(29,'days')
            });

            $(a).on('apply.daterangepicker',function(ev, picker){
                $(this).find('span').html(picker.startDate.format('MMMM D, YYYY') + ' - ' + picker.endDate.format('MMMM D, YYYY'));
                $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));

                $('#date-from').val(picker.startDate.format('YYYY-MM-DD'));
                $('#date-to').val(picker.endDate.format('YYYY-MM-DD'));

                Traffic.totalTraffic();
                Traffic.chartData('.chart-traffic');
                Traffic.bigTable('#all-traffic', 'visits', 1);
                Traffic.bigTable('#pageviews-traffic', 'pageviews', 1);
                Traffic.bigTable('#country-traffic', 'country', 1);
            });
        },
        init : function(){
            this.dateRangePicker('.bootstrap-daterangepicker-dropdown');
            this.totalTraffic();
            this.chartData('.chart-traffic');
            this.bigTable('#all-traffic', 'visits', 1);
            this.bigTable('#pageviews-traffic', 'pageviews', 1);
            this.bigTable('#country-traffic', 'country', 1);
        }
    };

    Traffic.init();

    $('.chart-view').on('click', '[data-target]', function(e){
        e.preventDefault();
        $(this).parents('.btn-group').find('.dropdown-toggle span.name').text($(this).text());
        $('.chart-traffic').data('method', $(this).data('target'));
        Traffic.chartData('.chart-traffic');
    });

    $('.bigTable').on('click', 'thead a', function(e){
        e.preventDefault();

        var $a = $(this).parents('.bigTable');
        var sort   = $(this).hasClass('desc') ? 'asc' : 'desc',
            sortby = $(this).data('of'),
            method = $a.data('method');
        $a.find('.sort').removeClass('desc asc');
        $(this).addClass(sort);
        $a.data({sort:sort, sortby:sortby});

        Traffic.bigTable('#'+$a.attr('id'), method, 1);
    });
});