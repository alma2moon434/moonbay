jQuery(document).ready(function(){
	
	jQuery('#generate_reviews').on('click', function(e){
		
		e.preventDefault();

        jQuery.ajax({
            url:  ajaxurl,
            data: {action:'but_action', go_code: true},
            type: "POST",
            success: function(data){
                if(data != "" && data != 0 ){
                	tt_set_product_reviews(data);                  
                } else {
                	if( data == 0 )  jQuery(".exp_info").html( "Generation is not required" );
                }
            }
        });

	});
	

	function tt_set_product_reviews(pos){

        pos = parseInt(pos);
        pos = Math.ceil(pos/20);

        if( pos > 0 ){

            var st = 1,
                len  = 100/pos;

            for( var p = 1; p <= pos; p++){

                jQuery.ajax({
                    url:  ajaxurl,
                    data: {action:'exp_set_reviews', step: p},
                    type: "POST",
                    beforeSend: function(){

                    },
                    success: function(data){
                        st = st + 1;
                        var per = Math.floor(len*st);
                        if(st <= pos) {
                            jQuery(".exp_info").html( "Step: "+ st +" of " + pos + '. ' + per + "%");
                        }     

                        //console.log(data);                                        
                    },
                    complete: function(){
                        if( st > pos ){
                            jQuery(".exp_info").html( "Completed" );
                        }                       
                    },
                    error: function(e) {
                        console.log(e.message);
                    }
                });
            }
        }
    }

});