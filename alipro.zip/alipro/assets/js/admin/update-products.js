/**
 * Created by Vitaly Kukin on 26.03.2016.
 */

jQuery( function ( $ ) {
		var param = {
			tId : null
		}
	var update = (function () {
		var $this,
			$body   = $( 'body' ),
			storage = {
				active : false
			};

		var obj = {
			'btn_start' : '#js-updateProduct'
		};

		var data = {
			"count"   : 0,
			"current" : 0,
			"update"  : 0,
			"insert"  : 0,
			"product" : {}
		};

		function setData( name, value, trigger ) {

			if ( typeof name === "string" ) {
				data[ name ] = value;
			} else {
				for ( var i in name ) {
					data[ i ] = name[ i ];
				}
				trigger = value;
			}

			if ( trigger !== true ) return;

			$body.trigger( {
				type  : "update:data",
				info  : data,
				chage : {
					name  : name,
					value : value
				}
			} );
		}

		function getInfo() {
			$.ajaxQueue( {
				url     : ajaxurl,
				data    : {
					action      : 'ali_update_product',
					ads_actions : 'info'
				},
				type    : "POST",
				success : function ( response ) {
					response = aliplugin.tryJSON( response );
					setData( response, true );
				}
			} );
		}

		function send( e ) {

			var $obj    = e.obj,
				post_id = e.index,
				url     = data.product[ post_id ][ 'productUrl' ],
				product = window.aliplugin.aliParseProduct.parseObj( $obj, url );

			var setting = {
				status : $( '#status' ).val(),
				cost   : $( '#cost' ).val()
			};

			$.ajaxQueue( {
				url     : ajaxurl,
				data    : {
					action      : 'ali_update_product',
					ads_actions : 'add',
					product     : aliplugin.b64EncodeUnicode( JSON.stringify( product ) ),
					post_id     : post_id,
					setting     : setting
				},
				type    : "POST",
				success : function ( response ) {
					response = aliplugin.tryJSON( response );
					setData( response, true );
					upload();
				}
			} );
		}

		function getNextProduct(next_step) {

			$.ajaxQueue( {
				url      : ajaxurl,
				data     : {
					action      : 'ali_update_product',
					ads_actions : 'next',
					stopped : next_step
				},
				type     : "POST",
				success  : function ( response ) {
					response     = aliplugin.tryJSON( response );
					data.current = response.current;
					if ( data.current != -1 ) {
						data.product[ response.post_id ] = {
							post_id    : response.post_id,
							product_id : response.product_id,
							productUrl : response.productUrl,
							stopped : response.stopped
						};
						window.aliplugin.aliExpansion.addTask( response.productUrl, send, $this, response.post_id );

					} else {
						data.product = {};
					}

					// console.log(response);
				},
				complete : function () {

				}
			} );
		}

		function upload() {

			if ( storage.active && data.current != -1 ) {
				getNextProduct();
			}

		}

		return {
			init : function () {

				var $this = this;
				$body.on( 'click', obj.btn_start, function () {
					if ( storage.active ) {
						storage.active = false;
					} else {
						storage.active = true;
						upload();
					}
				} );

				getInfo();
			}
		}
	})();
	update.init();

	/**
	 * title +count
	 * @type {{init}}
	 */
	var updateInfo;
	updateInfo = (function () {
		var $this;
		var $body = $( 'body' );

		var data = {
			list : []
		};

		var obl  = {
			$list : $( '#ali-activities-list' )
		};
		var tmpl = {
			list : $( '#tmpl-activities-list' ).html()
		};


		return {
			init           : function () {
				$this = this;

				ChartsKnob.init();

				$( 'body' ).on( 'update:data', function ( e ) {

					if ( e.info.hasOwnProperty( 'list' ) ) {
						$this.setList( e.info.list );
					}
					$this.renderProgress( e.info );
				} );
			},
			renderProgress : function ( info ) {
				var c  = info.current,
					i  = parseInt( info.count );
				var pr = parseInt( c / i * 100 );
				$( '#js-update-progress' ).val( pr ).trigger( 'change' );
			},
			renderList     : function () {
				obl.$list.html( aliplugin.objTotmpl( tmpl.list, data ) );
			},
			setList        : function ( list ) {

				data.list.push( {
					title   : list.title,
					count   : list.count > 0 ? '+' + list.count : 0,
					img     : list.img,
					caption : list.caption
				} );

				if ( data.list.length > 10 )
					data.list.splice( 0, 1 );

				$this.renderList();
			}
		}
	})();

	updateInfo.init();
} );