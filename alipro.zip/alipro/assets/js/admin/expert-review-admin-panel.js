jQuery(document).ready(function () {

  jQuery('#generate_reviews').on('click', function (e) {

    e.preventDefault();

    jQuery.ajax({
      url: ajaxurl,
      data: {action: 'but_action', go_code: true},
      type: "POST",
      success: function (data) {

        console.log(data);

        if (data != "" && data != 0) {
          tt_set_product_reviews(data);
        } else {
          if (data == 0)  jQuery(".exp_info").html("Generation is not required");
        }
      },

      error: function (data) {
        jQuery(".exp_info").html("Error, please try again later");
      }
    });

  });


  function tt_set_product_reviews(pos) {

    pos = parseInt(pos);
    pos = Math.ceil(pos / 20);

    if (pos > 0) {

      var st = 1,
        len = 100 / pos;

      for (var p = 1; p <= pos; p++) {
        console.log("ajax request");
        jQuery.ajax({
          url: ajaxurl,
          data: {action: 'exp_set_reviews', step: p},
          type: "POST",
          beforeSend: function () {

          },
          success: function (data) {
            console.log("success");
            st = st + 1;
            var per = Math.floor(len * st);
            if (st <= pos) {
              jQuery(".exp_info").html("Step: " + st + " of " + pos + '. ' + per + "%");
            }

            console.log(data);
          },
          complete: function () {
            console.log("complete");
            if (st > pos) {
              jQuery(".exp_info").html("Completed");
            }
          },
          error: function (e) {
            console.log("error");
            console.log(e.message);
          }
        });
      }
    }
  }

});